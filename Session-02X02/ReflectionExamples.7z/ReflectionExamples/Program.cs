﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ReflectionExamples
{
    public class Program
    {
        public static void Main()
        {
            var people = new List<Person>
            {
                new Person("Pavel Bartoș", "Miercurea Ciuc", new Country {Name = "Romania", LegalDrinkingAge = 18}, 46),
                new Person("Molly", "Beaconsfield", new Country {Name = "United Kingdom", LegalDrinkingAge = 18}, 31),
                new Person("Björk", "Reykjavík", new Country {Name = "Iceland", LegalDrinkingAge = 20}, 55),
            };

            Console.WriteLine("Types");
            Console.WriteLine(people[0].GetType());
            Console.WriteLine(people[0].Country.GetType());

            Console.WriteLine("Assemblies");
            Console.WriteLine(people[0].GetType().Assembly);
            Console.WriteLine(people[0].Country.GetType().Assembly);

            
            Console.WriteLine("Exercise");
            //Exercise:
            //How do we find how old Pavel Bartoș is?

            //find Pavel Bartoș in the List
            var pavelBartosPerson = people.Where(person => person.Name == "PAVEL BARTOȘ").First();

            //get the underlying type
            var type = pavelBartosPerson.GetType();

            //get the private field "age"
            BindingFlags bindFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
            FieldInfo field = type.GetField("age", bindFlags);

            //get the value of the field
            Console.WriteLine("Pavel Bartos is " + field.GetValue(pavelBartosPerson) + " years old.");
            
        }

        public class Person
        {
            public Person(string name, string city, Country country, int age)
            {
                this.name = name;
                this.city = city;
                this.country = country;
                this.age = age;
            }

            private readonly string name;
            private readonly string city;
            private readonly Country country;
            private readonly int age;

            public string Name => name.ToUpper();

            public string City => city.ToUpper();

            public string Country => country.Name.ToUpper();

            public bool IsOfLegalDrinkingAge => age >= country.LegalDrinkingAge;
        }

        public class Country
        {
            public string Name;
            public int LegalDrinkingAge;
        }



    }
}